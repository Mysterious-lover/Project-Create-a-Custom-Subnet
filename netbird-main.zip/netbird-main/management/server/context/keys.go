package context

const (
	RequestIDKey = "requestID"
	AccountIDKey = "accountID"
	UserIDKey    = "userID"
	PeerIDKey    = "peerID"
)
