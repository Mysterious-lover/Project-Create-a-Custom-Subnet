package dns

func CheckUncleanShutdown(string) error {
	return nil
}
