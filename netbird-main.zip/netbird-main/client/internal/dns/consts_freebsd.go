package dns

const (
	fileUncleanShutdownResolvConfLocation  = "/var/db/netbird/resolv.conf"
	fileUncleanShutdownManagerTypeLocation = "/var/db/netbird/manager"
)
