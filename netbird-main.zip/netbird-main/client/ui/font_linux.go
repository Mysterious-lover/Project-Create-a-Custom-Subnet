//go:build !386

package main

func (s *serviceClient) setDefaultFonts() {
	//TODO: Linux Multiple Language Support
}
