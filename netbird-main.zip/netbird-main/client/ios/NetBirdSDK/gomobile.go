package NetBirdSDK

import _ "golang.org/x/mobile/bind"

// to keep our CI/CD that checks go.mod and go.sum files happy, we need to import the package above
