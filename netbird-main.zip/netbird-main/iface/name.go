//go:build linux || windows || freebsd

package iface

// WgInterfaceDefault is a default interface name of Wiretrustee
const WgInterfaceDefault = "wt0"
