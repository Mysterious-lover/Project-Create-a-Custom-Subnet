//go:build darwin

package iface

// WgInterfaceDefault is a default interface name of Wiretrustee
const WgInterfaceDefault = "utun100"
